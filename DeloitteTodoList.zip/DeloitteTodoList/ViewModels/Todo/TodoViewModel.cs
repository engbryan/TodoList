using DeloitteTodoList.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace DeloitteTodoList.ViewModels
{
    [Bind("Item")]
    public class TodoViewModel
    {
        public IEnumerable<TodoItem> Items { get; set; }
    }
}