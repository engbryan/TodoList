﻿using DeloitteTodoList.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeloitteTodoList.Data
{
    public interface IRepository <T> where T : IDataModel<T>
    {
        bool Add(T model);
        bool Update(T model);
        T Get(int id);
        IEnumerable<T> Get();
        bool Delete(int id);
        bool Delete(T model);
    }
}
