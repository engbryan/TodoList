﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeloitteTodoList.Models
{
    public interface IDataModel <T> where T : IDataModel<T>
    {
        int Id { get; set; }
    }
}
