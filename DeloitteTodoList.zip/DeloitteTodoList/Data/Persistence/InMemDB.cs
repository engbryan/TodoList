﻿using DeloitteTodoList.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeloitteTodoList.Data.Persistence
{
    public static class InMemDB
    {
        public static List<ApplicationUser> Users { get; } = new List<ApplicationUser>();
        public static List<TodoItem> TodoItems { get; } = new List<TodoItem>();

        static InMemDB()
        {
            ApplicationUser usr1 = new ApplicationUser()
            {
                Id = 1,
                FullName = "Bryan",
                Email = "bryanteixeira@outlook.com",
                Password = "1234"
            };

            Users.Add(new ApplicationUser()
            {
                Id = 1,
                FullName = "Bryan",
                Email = "bryanteixeira@outlook.com",
                Password = "1234"
            });

            Users.Add(new ApplicationUser()
            {
                Id = 2,
                FullName = "Deloitte",
                Email = "teams@deloitte.ie",
                Password = "abcd"
            });

            TodoItems.Add(new TodoItem()
            {
                Id = 1,
                Title = "Send to deloitte",
                Owner = usr1,
                Created = DateTime.Now
            });

        }
    }
}
