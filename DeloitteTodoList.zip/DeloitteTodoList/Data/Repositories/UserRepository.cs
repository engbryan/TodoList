﻿using DeloitteTodoList.Data.Persistence;
using DeloitteTodoList.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeloitteTodoList.Data
{
    public class UserRepository : Repository<ApplicationUser>
    {
        public UserRepository(List<ApplicationUser> source = null)
            : base(source != null ? source : InMemDB.Users)
        { }

        public ApplicationUser GetByEmailAndPassword(string email, string password)
        {
            return Entities.SingleOrDefault(user => user.Email == email && user.Password == password);
        }

        internal ApplicationUser GetByEmail(string email)
        {
            return Entities.SingleOrDefault(user => user.Email == email);
        }
    }
}
