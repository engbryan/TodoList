﻿using DeloitteTodoList.Data.Persistence;
using DeloitteTodoList.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeloitteTodoList.Data
{
    public class TodoRepository : Repository<TodoItem>
    {
        public TodoRepository(List<TodoItem> source = null)
            : base(source != null ? source : InMemDB.TodoItems)
        { }

        public IEnumerable<TodoItem> GetFromUser(ApplicationUser user)
        {
            return Entities
                .Where(todo => todo.Owner.Id == user.Id);
        }

        public IEnumerable<TodoItem> GetDone(ApplicationUser user)
        {
            return GetFromUser(user)
                .Where(todo => todo.IsDone == true);
        }

        public IEnumerable<TodoItem> GetIncomplete(ApplicationUser user)
        {
            return GetFromUser(user)
                .Where(todo => todo.IsDone == false);
        }

    }
}
