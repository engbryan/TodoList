﻿using DeloitteTodoList.Data.Persistence;
using DeloitteTodoList.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DeloitteTodoList.Data
{
    public class Repository<T> : IRepository<T>
        where T : IDataModel<T>
    {
        int _idIndex = 1;

        protected IList<T> Entities { get; }

        public Repository(IList<T> source)
        {
            this.Entities = source;
            _idIndex = _getFreshIndexer();
        }

        private int _getFreshIndexer()
        {
            if (Entities.Any(ent => ent.Id == _idIndex))
                return _idIndex = Entities.Max(ent => ent.Id) + 1;

            return _idIndex++;
        }

        public bool Add(T entity)
        {
            entity.Id = _getFreshIndexer();

            Entities.Add(entity);
            return true;
        }

        public bool Update(T entity)
        {
            T _entity = Entities.SingleOrDefault(ent => ent.Id == entity.Id);

            if (_entity != null)
            {
                _entity = entity;
                return true;
            }

            return false;
        }

        public T Get(int id)
        {
            return Entities.SingleOrDefault(entity => entity.Id == id);
        }

        public IEnumerable<T> Get()
        {
            return Entities;
        }

        public bool Delete(int id)
        {
            T entity = Get(id);

            if (entity != null)
            {
                return Entities.Remove(entity);
            }

            return false;
        }

        public bool Delete(T entity)
        {
            return Delete(entity.Id);
        }

    }
}
