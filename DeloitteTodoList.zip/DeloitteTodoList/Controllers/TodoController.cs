using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DeloitteTodoList.Data;
using DeloitteTodoList.Models;
using DeloitteTodoList.Services;
using DeloitteTodoList.ViewModels;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace DeloitteTodoList.Controllers
{
    [Route("[controller]")]
    public class TodoController : Controller
    {
        private readonly ITodoItemService _todoItemService;
        private readonly IUserService _userService;

        public TodoController(ITodoItemService todoItemService, IUserService userService)
        {
            _todoItemService = todoItemService;
            _userService = userService;
        }

        [HttpGet(Name = "Index Action")]
        public async Task<IActionResult> Index()
        {
            ApplicationUser currentUser = _userService.GetCurrentUser(HttpContext);
            if (currentUser == null) return Challenge();

            var todoItems = await _todoItemService.GetIncompleteItemsAsync(currentUser);

            var model = new TodoViewModel()
            {
                Items = todoItems
            };

            return View(model);
        }

        [Route("AddItem")]
        public async Task<IActionResult> AddItem(TodoItem newItem)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction("Index");
            }

            ApplicationUser currentUser = _userService.GetCurrentUser(HttpContext);
            if (currentUser == null) return Challenge();

            var successful = await _todoItemService.AddItemAsync(newItem, currentUser);
            if (!successful) 
            {
                return BadRequest(new { error = "Could not add item." });
            }

            return RedirectToAction("Index");
        }

        [Route("MarkDone")]
        public async Task<IActionResult> MarkDone(int id)
        {
            if (id == 0)
            {
                return RedirectToAction("Index");
            }

            ApplicationUser currentUser = _userService.GetCurrentUser(HttpContext);
            if (currentUser == null) return Challenge();

            var successful = await _todoItemService.MarkDoneAsync(id);
            if (!successful)
            {
                return BadRequest("Could not mark item as done.");
            }

            return RedirectToAction("Index");
        }


    }

}