using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTodoList.Models;

namespace DeloitteTodoList.Services
{
    public interface ITodoItemService
    {
        Task<IEnumerable<TodoItem>> GetIncompleteItemsAsync(ApplicationUser user);
        Task<bool> AddItemAsync(TodoItem newItem, ApplicationUser user);
        Task<bool> MarkDoneAsync(int id);
    }
}
