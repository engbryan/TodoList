using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeloitteTodoList.Data;
using DeloitteTodoList.Models;
using Microsoft.EntityFrameworkCore;

namespace DeloitteTodoList.Services
{
    public class TodoItemService : ITodoItemService
    {
        private readonly TodoRepository _repository;

        public TodoItemService()
        {
            _repository = new TodoRepository();
        }

        public async Task<bool> AddItemAsync(TodoItem newItem, ApplicationUser user)
        {
            var entity = new TodoItem
            {
                Owner = user,
                IsDone = false,
                Title = newItem.Title,
                Created = DateTime.Now
            };

            return await Task.Run(() =>
            {
                return _repository.Add(entity);
            });
        }

        public async Task<IEnumerable<TodoItem>> GetIncompleteItemsAsync(ApplicationUser user)
        {
            return await Task.Run(() =>
            {
                return _repository.GetIncomplete(user);
            });
        }

        public async Task<bool> MarkDoneAsync(int id)
        {
            return await Task.Run(() =>
            {
                var item = _repository.Get(id);

                if (item == null) return false;

                item.IsDone = true;

                return true;
            });
        }

        public async Task<IEnumerable<TodoItem>> HistoryAsync(ApplicationUser user)
        {
            return await Task.Run(() =>
            {
                return _repository.GetFromUser(user);
            });
        }

    }
}