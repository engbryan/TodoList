using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DeloitteTodoList.Data;
using DeloitteTodoList.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace DeloitteTodoList.Services
{
    public class UserService : IUserService
    {
        private readonly UserRepository _repository;

        public UserService()
        {
            _repository = new UserRepository();
        }

        public ApplicationUser Authenticate(string email, string password)
        {
            return _repository.GetByEmailAndPassword(email, password);
        }


        public bool IsAuthenticated(string email)
        {
            return _repository.Get().Any(user => user.Email == email);
        }

        public ApplicationUser GetCurrentUser(HttpContext context)
        {
            if (context.User == null || context.User.Identity == null) return null;

            string email = context.User.Identity.Name;

            ApplicationUser user = _repository.GetByEmail(email);

            return _repository.Get().SingleOrDefault(_user => _user.Email == email);
        }

    }
}