using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DeloitteTodoList.Models;
using Microsoft.AspNetCore.Http;

namespace DeloitteTodoList.Services
{
    public interface IUserService
    {
        ApplicationUser Authenticate(string email, string password);
        bool IsAuthenticated(string email);
        ApplicationUser GetCurrentUser(HttpContext context);
    }
}
