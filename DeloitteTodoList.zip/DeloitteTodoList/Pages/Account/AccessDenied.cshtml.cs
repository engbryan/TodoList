using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DeloitteTodoList.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
