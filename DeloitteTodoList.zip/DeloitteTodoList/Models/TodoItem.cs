using DeloitteTodoList.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace DeloitteTodoList.Models
{
    public class TodoItem : IDataModel<TodoItem>
    {
        public int Id { get; set; }
        public bool IsDone { get; set; }

        [Required]
        public string Title { get; set; }

        public ApplicationUser Owner { get; set; }

        public DateTime Created { get; set; }
    }
}